﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MJC.model
{
    public class PrintOrder
    {
        public string AcctNumber { get; set; }
        public string Date { get; set; }
        public string PONumber { get; set; }
        public string ShipVia { get; set; }
        public string Terms { get; set; }
    }
}
